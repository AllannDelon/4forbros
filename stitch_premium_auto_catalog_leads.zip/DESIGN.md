---
name: Apex Velocity
colors:
  surface: '#10141a'
  surface-dim: '#10141a'
  surface-bright: '#353940'
  surface-container-lowest: '#0a0e14'
  surface-container-low: '#181c22'
  surface-container: '#1c2026'
  surface-container-high: '#262a31'
  surface-container-highest: '#31353c'
  on-surface: '#dfe2eb'
  on-surface-variant: '#c1c6d7'
  inverse-surface: '#dfe2eb'
  inverse-on-surface: '#2d3137'
  outline: '#8b90a1'
  outline-variant: '#414755'
  surface-tint: '#aec6ff'
  primary: '#aec6ff'
  on-primary: '#002e6a'
  primary-container: '#4f8eff'
  on-primary-container: '#00275e'
  inverse-primary: '#005ac4'
  secondary: '#b2c5ff'
  on-secondary: '#002b74'
  secondary-container: '#0050cb'
  on-secondary-container: '#c2d0ff'
  tertiary: '#c2c7d0'
  on-tertiary: '#2c3138'
  tertiary-container: '#8c919a'
  on-tertiary-container: '#252a31'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#aec6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004396'
  secondary-fixed: '#dae2ff'
  secondary-fixed-dim: '#b2c5ff'
  on-secondary-fixed: '#001849'
  on-secondary-fixed-variant: '#003fa3'
  tertiary-fixed: '#dee2ec'
  tertiary-fixed-dim: '#c2c7d0'
  on-tertiary-fixed: '#171c23'
  on-tertiary-fixed-variant: '#42474f'
  background: '#10141a'
  on-background: '#dfe2eb'
  surface-variant: '#31353c'
typography:
  display-lg:
    fontFamily: Rajdhani
    fontSize: 64px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Rajdhani
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Rajdhani
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Rajdhani
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-bold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.05em
  button:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style

The design system embodies a "High-Performance Digital Showroom" aesthetic. It is tailored for a premium automotive audience that values precision engineering, speed, and futuristic technology. The visual language evokes the feeling of a late-night drive through a neon-lit metropolis—dark, focused, and electrifying.

The design style is a sophisticated blend of **Modern Corporate** structure and **Glassmorphism**. It utilizes deep, ink-like surfaces contrasted with vibrant electric blue accents to create a sense of depth and luminescence. Every interaction should feel like operating a high-end vehicle dashboard: responsive, tactile, and ultra-modern.

## Colors

The palette is anchored in high-contrast "After Hours" tones. 
- **Primary Electric Blue (#0077FF):** Used for critical actions, active states, and glowing accents. It mimics the luminescence of LED headlights and fiber-optic interior lighting.
- **Surface Neutrals:** The foundation is **Black (#0D1117)** for backgrounds, providing an infinite depth. **Graphite (#1A1F26)** and **Dark Gray (#2A3038)** are used for layered components and cards to create structural separation.
- **Functional White (#FFFFFF):** Reserved for maximum legibility of headlines and primary body text.

## Typography

The typography system pairs a technical, condensed geometric display face with a highly legible sans-serif for functional content.

- **Display & Headlines:** Rajdhani brings a "heads-up display" (HUD) feel to the interface. Its squared-off terminals and condensed proportions mirror automotive instrumentation.
- **Body & Controls:** Inter is utilized for its neutral, utilitarian clarity. It ensures that technical specifications and user inputs remain legible against dark, blurred backgrounds. 
- **Stylistic Note:** All uppercase styling is encouraged for `label-bold` and `display-lg` roles to emphasize a bold, authoritative tone.

## Layout & Spacing

The layout follows a **Fluid Grid** model designed to feel expansive and cinematic. 
- **Desktop:** A 12-column grid with generous 64px outer margins. Content is encouraged to use asymmetrical placement to mimic the sleek, dynamic lines of a sports car.
- **Mobile:** A 4-column grid with 16px margins. Vertical stack patterns dominate, ensuring touch targets are large and accessible.
- **Spacing Rhythm:** An 8px linear scale is used. Consistent 24px (md) gutters ensure breathing room between technical data points and imagery.

## Elevation & Depth

Hierarchy is achieved through **Glassmorphism** and **Luminous Outlines** rather than traditional heavy shadows.

- **Background Surfaces:** Deep #0D1117.
- **Component Layering:** Components use #1A1F26 with a 60% opacity backdrop-filter (blur: 12px). This creates a "frosted tech" appearance.
- **Border Treatment:** Instead of shadows, use 1px inner borders with a linear gradient (top-left: White @ 10% to bottom-right: White @ 2%).
- **Active Glow:** Interactive elements in a "pressed" or "active" state should emit a soft #0077FF outer glow (spread: 15px, opacity: 20%) to simulate light emission.

## Shapes

The shape language balances technical precision with organic flow. 
- **Standard Radius:** 8px (0.5rem) for most buttons and inputs, providing a modern, approachable feel.
- **Container Radius:** 16px (1rem) for cards and modals to soften the overall dark aesthetic and frame high-quality automotive photography.
- **Detailing:** Icons and small UI accents should utilize sharp angles or perfect circles to contrast with the rounded containers.

## Components

- **Buttons:** Primary buttons feature a solid #0077FF fill with white text. Secondary buttons are "Ghost" style with a 1px Electric Blue border and a subtle backdrop blur.
- **Cards:** Utilize the glassmorphic style. Background: #1A1F26 at 80% opacity, 12px blur, and a 1px top-light border.
- **Input Fields:** Dark Graphite background with a subtle inner shadow. On focus, the border transitions to a solid Electric Blue with a soft neon glow.
- **Chips/Status Tags:** Semi-transparent capsules. For performance metrics (e.g., "0-60 mph"), use a high-contrast Electric Blue label on a dark tint.
- **Lists:** Clean, borderless rows separated by subtle 1px dividers (#2A3038).
- **Automotive Special Components:**
    - **Telemetry Gauges:** Circular progress indicators using Electric Blue gradients.
    - **Feature Hero Panels:** Full-bleed image containers with bottom-aligned Rajdhani typography overlays.